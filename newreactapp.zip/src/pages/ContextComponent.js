import React, {Component} from 'react';
import {UserConsumer} from './userContext';

export class ContextComponent extends Component {
  render () {
    return (
      <React.Fragment>
        <ul>
          <UserConsumer>

            {data => {
              return data.employees.map (emp => (
                <li>{emp.name}---{emp.email}</li>
              ));
            }}

          </UserConsumer>
        </ul>
      </React.Fragment>
    );
  }
}

export default ContextComponent;
