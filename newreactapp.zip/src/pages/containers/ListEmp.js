import React from 'react'

function ListEmp(props) {
  return (
     <React.Fragment>
        <td>{props.id}</td>
        <td>{props.fullName}</td>
        <td>{props.email}</td>
        <td><img src={props.photo} width="100px" height="100px"/></td>
     </React.Fragment>
  )
}

export default ListEmp
