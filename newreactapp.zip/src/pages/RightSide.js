import React from 'react'
import Img from './images/side.png'
function RightSide() {
  return (
    <div>
        <h2>Right Area</h2>
        <img src={Img} width="350px"/>
    </div>
  )
}

export default RightSide
