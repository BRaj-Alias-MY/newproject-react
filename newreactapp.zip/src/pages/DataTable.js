import React, {Component} from 'react';
import {UserConsumer} from './userContext';

export class DataTable extends Component {
  render () {
    return (
      <React.Fragment>
        <h2>DataTable Component</h2>
        <UserConsumer>
          {username => {
            return <h2>Welcome {username}</h2>;
          }}
        </UserConsumer>
      </React.Fragment>
    );
  }
}

export default DataTable;
