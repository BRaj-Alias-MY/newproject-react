import React, { Component } from 'react'
import AddForm from './containers/AddForm'
export class AddEmployee extends Component {
  render() {
    return (
      <React.Fragment>
        <h2>AddEmployee</h2>
        <br/>
           <AddForm/>
      </React.Fragment>
    )
  }
}

export default AddEmployee
