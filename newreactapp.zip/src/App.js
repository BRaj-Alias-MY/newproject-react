import React, {Component} from 'react';
import logo from './logo.svg';
import './App.css';
import Main from './Main';
import {UserProvider} from './pages/userContext';

class App extends Component {
  state = {
    story: 'employee',
    employees: [
      {name: 'Muraly', email: 'Muraly@gmail.com'},
      {name: 'Vikram', email: 'Vikram@gmail.com'},
    ],
  };
  render () {
    return (
      <div className="">
        <UserProvider value={this.state}>
          <Main />
        </UserProvider>

      </div>
    );
  }
}

export default App;
