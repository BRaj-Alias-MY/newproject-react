var express = require ('express');
var fs = require ('fs');

var router = express.Router ();
// handle multipart form data
const multer = require ('multer');
const path = require ('path');
const models = require ('../models');
const User = models.User;

 const storage = multer.diskStorage({
   destination: "./public/uploads/",
   filename: function(req, file, cb){
      var a = cb(null, req.params.name + path.extname(file.originalname));
       console.log( );
   }
     
});

const upload = multer({
   storage: storage,
   limits:{fileSize: 1000000},
}).single("myImage");


//var upload = multer({ storage : storage}).single('userPhoto');

 
router.post('/upload/:name',function(req,res){
            
    upload(req,res,function(err) {
        if(err) {
            return res.end("Error uploading file.");
        }
        res.end("File is uploaded");
    });
});

router.post ('/add',  (req, res) => {
    
  User.create ({
    fullName: req.body.fullName,
    email: req.body.email,
    password: req.body.password,
    photo: 'http://localhost:8000/public/uploads/' + req.body.fullName + '.' + 'png',
  })
    .then (user => {
      res.status (201).send (user);
    })
    .catch (err => {
      res.render ('error', err);
    });
});

//get data
router.get ('/userlist', (req, res) => {
  console.log (req);
  User.findAll ()
    .then (users => res.status (201).send (users))
    .catch (err => console.log (err));
});

module.exports = router;
