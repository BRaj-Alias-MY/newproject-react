import React, { Component } from 'react'
import axios from 'axios'
import ListEmp from './containers/ListEmp'
export class ListEmployees extends Component {
  constructor(props) {
    super(props)

    this.state = {
        users : []
    }
  }
  componentDidMount(){
      axios.get('http://localhost:8000/api/userlist').then(resp => {
        console.log(resp);
        this.setState({
          users : resp.data
        })
      }).catch(err=>console.log(err));
  }
  render() {

    return (
        <React.Fragment>
         <table className="table table-hovered">
          <thead>
            <tr>
            <th>S.No</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Photo</th>
            </tr>
            </thead>
            <tbody>

            {this.state.users.map (user => (
              <tr key={user.id}>
                <ListEmp {...user} />
              </tr>
            ))}


            </tbody>

         </table>
        </React.Fragment>
    )
  }
}

export default ListEmployees
