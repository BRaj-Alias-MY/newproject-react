import React, { Component } from 'react'

export class DataTable extends Component {
  render() {
    return (
       <React.Fragment>
       <h2>DataTable Component</h2>
      </React.Fragment>
    )
  }
}

export default DataTable
