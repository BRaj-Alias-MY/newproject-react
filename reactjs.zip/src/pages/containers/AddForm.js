import React, { Component } from 'react'
import axios from 'axios'
export class AddForm extends Component {
    constructor(props) {
      super(props)

      this.state = {
            fullName: null,
            email: null,
            password: null,
            message: null,
            photo: null,
            selectedFile: null
      }
      this.onFormSubmit = this.onFormSubmit.bind(this);
    }
    submitHandler = e => {
        e.preventDefault();
        axios.post('http://localhost:8000/api/add',this.state)
        .then(resp => {
          this.onFormSubmit(this.state.fullName);
          this.setState({
            message: 'User Registration Successfully!'
        })

        })
        .catch(err=>console.log(err));
    }
    changeHandler = (e) => {
        this.setState({
            [e.target.name]  : e.target.value
        })
    }
    fileSelectHandler = event => {
        this.setState({ selectedFile:  event.target.files[0] });
        console.log(event.target.files[0])
      }

      onFormSubmit(name){
      //  e.preventDefault();
        const formData = new FormData();
        formData.append('myImage',this.state.selectedFile);
        const config = {
          headers: {
              'content-type': 'multipart/form-data'
          }
      };
        axios.post("http://localhost:8000/api/upload/" + name,formData,config)
            .then((response) => {
               // alert("The file is successfully uploaded");
            }).catch((error) => {
        });
      }


  render() {
    return (
      <div className="container">
      <form onSubmit={this.submitHandler}  encType="multipart/form-data">
            <div className="">
            <label  ><b>Username: </b></label>
            <input type="text" className="form-control" placeholder="Enter Username" onChange = {this.changeHandler} name="fullName" required/>


                <label ><b>Email</b></label>
                <input type="email" className="form-control" placeholder="Enter Email"  onChange = {this.changeHandler}  name="email" required/>

                <label  ><b>Password</b></label>
                <input type="password" className="form-control" placeholder="Enter Password"   ref="image"  onChange = {this.changeHandler}  name="password" required/>
                <br/>
                <label  ><b>Upload Image</b></label>
                <input type="file" name="myImage" onChange = {this.fileSelectHandler}/>
                <div>
                <br/>
                <button type="submit" className="btn btn-primary">Register</button>
                 <br/>
                <br/>
                <h4>{this.state.message}</h4>
                </div>

            </div>

    </form>
      </div>
    )
  }
}

export default AddForm
