import React, { Component } from 'react'
import Home from "./pages/Home";
import AddEmployee from "./pages/AddEmployee";
import ListEmployees from "./pages/ListEmployees";
import DataTable from "./pages/DataTable";
import Contact from "./pages/Contact";
import RightSide from "./pages/RightSide"

import {
    Route,
    NavLink,
    BrowserRouter,
    Switch


  } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

export class Main extends Component {
  render() {

    return (
        <BrowserRouter>

        <React.Fragment>

  <nav className="navbar navbar-expand-lg navbar-light bg-light">
  <NavLink className="navbar-brand" to="/">ReactJS</NavLink>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>
  <div className="collapse navbar-collapse" id="navbarText">
    <ul className="navbar-nav mr-auto">
      <li className="nav-item">
        <NavLink className="nav-link"  to="/">Home  </NavLink>
      </li>
      <li className="nav-item">
        <NavLink className="nav-link"  to="/addemployee">Add Employee</NavLink>
      </li>
      <li className="nav-item">
      <NavLink className="nav-link"  to="/listemployees">List Employees</NavLink>
      </li>
      <li className="nav-item">
      <NavLink className="nav-link"  to="/DataTable">DataTable</NavLink>
      </li>

      <li className="nav-item">
      <NavLink className="nav-link"  to="/Contact">Contact</NavLink>
      </li>


    </ul>
    <span className="navbar-text">
    <NavLink className="nav-link"  to="/Logout">Logout</NavLink>
    </span>
  </div>
</nav>

     <div className="container-fluid">
      <div className="row">
        <div className="col-md-8">
        <div  className="content">
        <Switch>
        <Route exact path="/" component={Home}/>
        <Route path="/addemployee" component={AddEmployee}/>
        <Route path="/listemployees" component={ListEmployees}/>
        <Route path="/datatable" component={DataTable}/>
        <Route path="/contact" component={Contact}/>
        <Route  component={Home}/>
        </Switch>
      </div>
      </div>
      <div className="col-md-4 custom-padding"  >
       <RightSide/>
      </div>

      </div>

      </div>


        </React.Fragment>

        </BrowserRouter>
    )
  }
}

export default Main
